# html-gtqsp

Gulp Tailwind Quick Start Pack

use `yarn start` to start development server
